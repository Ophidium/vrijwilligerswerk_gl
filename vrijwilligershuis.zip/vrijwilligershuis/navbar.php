<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navbar</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <nav>
        <h1 id="navbarTitle">99</h1>
        <ul>
            <li>Home</li>
            <li>Over ons</li>
            <li>Contact</li>
        </ul>
    </nav>
</body>
</html>